package com.example.petshop;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class cadastrotela extends AppCompatActivity {
    EditText email, senha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_cadastrotela);
        email = findViewById(R.id.cUsuario);
        senha = findViewById(R.id.cSenha);
    }

    public void cadastrar(View view){
        String e = email.getText().toString();
        String s = senha.getText().toString();
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(e,s).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    startActivity(new Intent(getApplicationContext(),logintela.class));
                } else {
                    Toast.makeText(getApplicationContext(), "ai deu erro", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}